import setuptools

setuptools.setup(
    name="MiaoSQL",
    version="0.0.5",
    author="LiuWenYu",
    author_email="1545113791@qq.com",
    description="更适合喵喵体质的mysql查询",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
