class NoQuiry(Exception):
    pass
